import { useMutation } from "@tanstack/react-query";
import { Check, Loader2, Plus, Printer, Settings, Usb, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { addLocationOption, removeLocationOption } from "@/lib/locations";
import { testBricklinkToken, testEbayToken } from "@/lib/server/sets";
import { testRoyalMailKey } from "@/lib/server/postage";
import { bricklinkCanSync, royalMailCanPost, useSettings } from "@/lib/settings";
import {
  BAUD_RATES,
  CONNECTION_MODES,
  DPI_OPTIONS,
  LABEL_SIZES,
  PRINT_LANGUAGES,
  clampDarkness,
  isHostPrint,
  type BaudRate,
  type ConnectionMode,
  type Dpi,
  type LabelSizeId,
  type PrintLanguage,
  usePrinter,
} from "@/lib/printer-settings";
import {
  SAMPLE_LABEL,
  pairSerialPort,
  pairUsbPrinter,
  printErrorMessage,
  printThermal,
  serialAvailable,
  usbAvailable,
} from "@/lib/thermal";
import { MARKETPLACES, type MarketplaceId } from "@/lib/types";

export function SettingsSheet() {
  const settings = useSettings();
  const setSettings = settings.setSettings;
  const printer = usePrinter();
  const [open, setOpen] = useState(false);
  const [pairing, setPairing] = useState<"usb" | "serial" | "test" | null>(null);
  const [locationDraft, setLocationDraft] = useState("");

  const test = useMutation({
    mutationFn: () =>
      testEbayToken({
        data: { token: settings.ebayUserToken, marketplace: settings.marketplace },
      }),
    onSuccess: (res) => toast.success(`Connected as ${res.userId}`),
    onError: (err) => toast.error(err instanceof Error ? err.message : "Token failed"),
  });

  const testBl = useMutation({
    mutationFn: () =>
      testBricklinkToken({
        data: {
          blConsumerKey: settings.blConsumerKey,
          blConsumerSecret: settings.blConsumerSecret,
          blToken: settings.blToken,
          blTokenSecret: settings.blTokenSecret,
        },
      }),
    onSuccess: (res) => toast.success(`BrickLink connected · ${res.lots} set lots`),
    onError: (err) => toast.error(err instanceof Error ? err.message : "BrickLink failed"),
  });

  const testRm = useMutation({
    mutationFn: () => testRoyalMailKey({ data: { royalMailApiKey: settings.royalMailApiKey } }),
    onSuccess: (res) => toast.success(`Click & Drop connected · ${res.release}`),
    onError: (err) => toast.error(err instanceof Error ? err.message : "Royal Mail failed"),
  });

  const pairUsb = async () => {
    setPairing("usb");
    try {
      const name = await pairUsbPrinter();
      printer.setPrinter({ lastPrinterName: name, connection: "usb" });
      toast.success(`Paired ${name}`);
    } catch (err) {
      toast.error(printErrorMessage(err));
    } finally {
      setPairing(null);
    }
  };

  const pairSerial = async () => {
    setPairing("serial");
    try {
      const name = await pairSerialPort();
      printer.setPrinter({ lastPrinterName: name, connection: "serial" });
      toast.success("Serial port paired");
    } catch (err) {
      toast.error(printErrorMessage(err));
    } finally {
      setPairing(null);
    }
  };

  const testPrint = async () => {
    setPairing("test");
    try {
      const result = await printThermal(SAMPLE_LABEL, {
        language: printer.language,
        sizeId: printer.sizeId,
        dpi: printer.dpi,
        darkness: clampDarkness(printer.darkness),
        copies: 1,
        connection: printer.connection,
        baudRate: printer.baudRate,
      });
      if (result === "sent") toast.success("Test label sent");
      else if (result === "downloaded") toast.success("Downloaded test label — pair a printer to send USB directly");
      else toast.success("System print opened");
    } catch (err) {
      toast.error(printErrorMessage(err));
    } finally {
      setPairing(null);
    }
  };

  const addLocation = () => {
    const result = addLocationOption(settings.locations ?? [], locationDraft);
    if ("error" in result) {
      toast.error(result.error);
      return;
    }
    setSettings({ locations: result.list });
    setLocationDraft("");
  };

  const removeLocation = (loc: string) => {
    setSettings({ locations: removeLocationOption(settings.locations ?? [], loc) });
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" aria-label="Settings">
          <Settings />
        </Button>
      </SheetTrigger>
      <SheetContent className="overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Settings</SheetTitle>
          <SheetDescription>
            Printer setup stays in this browser. API keys are sent with listing and price requests, never stored in the database.
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 px-5 pb-8">
          <section className="space-y-3">
            <h3 className="text-sm font-medium">Locations</h3>
            <p className="text-sm text-muted">
              Bins and shelves for the Location dropdown on each lot. Location labels print only this code.
            </p>
            {!(settings.locations ?? []).length ? (
              <p className="text-sm text-muted">None yet. Add A-12, BIN-03, SHELF B4…</p>
            ) : (
              <ul className="space-y-2">
                {(settings.locations ?? []).map((loc) => (
                  <li
                    key={loc}
                    className="flex items-center gap-2 rounded-md bg-surface px-3 py-1.5 shadow-[var(--shadow-border)]"
                  >
                    <span className="min-w-0 flex-1 font-mono text-sm">{loc}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="size-10 shrink-0 px-0"
                      aria-label={`Remove ${loc}`}
                      onClick={() => removeLocation(loc)}
                    >
                      <X />
                    </Button>
                  </li>
                ))}
              </ul>
            )}
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                addLocation();
              }}
            >
              <Input
                id="new-location"
                value={locationDraft}
                onChange={(e) => setLocationDraft(e.target.value)}
                className="font-mono"
                placeholder="A-12"
                maxLength={40}
                aria-label="New location"
              />
              <Button type="submit" variant="secondary" className="shrink-0">
                <Plus />
                Add
              </Button>
            </form>
          </section>

          <Separator />

          <section className="space-y-3">
            <h3 className="text-sm font-medium">Thermal printer</h3>
            <p className="text-sm text-muted">
              Set up for Brother QL-1110NWB. Choose Brother print service to print through the Brother driver / Print Service Plugin. DK roll sizes are listed below. ZPL / TSPL / EPL stay available for other printers.
            </p>
            <div className="space-y-2">
              <Label>Language</Label>
              <Select
                value={printer.language}
                onValueChange={(v) => printer.setPrinter({ language: v as PrintLanguage })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRINT_LANGUAGES.map((l) => (
                    <SelectItem key={l.id} value={l.id}>
                      {l.label} · {l.hint}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Label size</Label>
                <Select
                  value={printer.sizeId}
                  onValueChange={(v) => printer.setPrinter({ sizeId: v as LabelSizeId })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {LABEL_SIZES.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>DPI</Label>
                <Select
                  value={String(printer.dpi)}
                  onValueChange={(v) => printer.setPrinter({ dpi: Number(v) as Dpi })}
                  disabled={isHostPrint(printer.language)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DPI_OPTIONS.map((d) => (
                      <SelectItem key={d} value={String(d)}>
                        {d} dpi
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Send via</Label>
                <Select
                  value={printer.connection}
                  onValueChange={(v) => printer.setPrinter({ connection: v as ConnectionMode })}
                  disabled={isHostPrint(printer.language)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CONNECTION_MODES.map((m) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="darkness">Darkness 0–30</Label>
                <Input
                  id="darkness"
                  inputMode="numeric"
                  value={String(printer.darkness)}
                  onChange={(e) => printer.setPrinter({ darkness: clampDarkness(Number(e.target.value) || 0) })}
                  disabled={isHostPrint(printer.language)}
                />
              </div>
              {printer.connection === "serial" && !isHostPrint(printer.language) && (
                <div className="space-y-2">
                  <Label>Baud</Label>
                  <Select
                    value={String(printer.baudRate)}
                    onValueChange={(v) => printer.setPrinter({ baudRate: Number(v) as BaudRate })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {BAUD_RATES.map((b) => (
                        <SelectItem key={b} value={String(b)}>
                          {b}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            {printer.lastPrinterName ? (
              <p className="text-xs text-muted">Last printer: {printer.lastPrinterName}</p>
            ) : null}
            <div className="flex flex-col gap-2">
              <Button
                variant="secondary"
                className="w-full"
                disabled={!usbAvailable() || pairing !== null}
                onClick={() => void pairUsb()}
              >
                {pairing === "usb" ? <Loader2 className="animate-spin" /> : <Usb />}
                Pair USB printer
              </Button>
              <Button
                variant="outline"
                className="w-full"
                disabled={!serialAvailable() || pairing !== null}
                onClick={() => void pairSerial()}
              >
                {pairing === "serial" ? <Loader2 className="animate-spin" /> : <Usb />}
                Pair serial port
              </Button>
              <Button variant="outline" className="w-full" disabled={pairing !== null} onClick={() => void testPrint()}>
                {pairing === "test" ? <Loader2 className="animate-spin" /> : <Printer />}
                Test print
              </Button>
            </div>
            {!usbAvailable() && !serialAvailable() && (
              <p className="text-xs leading-relaxed text-muted">
                This browser cannot open USB or serial printers. Print labels will download a command file, or use system print.
              </p>
            )}
          </section>

          <Separator />

          <section className="space-y-3">
            <h3 className="text-sm font-medium">Marketplace</h3>
            <div className="space-y-2">
              <Label>eBay site</Label>
              <Select
                value={settings.marketplace}
                onValueChange={(v) => setSettings({ marketplace: v as MarketplaceId })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MARKETPLACES.map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.label} · {m.currency}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={settings.city}
                  onChange={(e) => setSettings({ city: e.target.value })}
                  placeholder="Manchester"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="zip">Postal code</Label>
                <Input
                  id="zip"
                  value={settings.postalCode}
                  onChange={(e) => setSettings({ postalCode: e.target.value })}
                  placeholder="M1 1AE"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ship">Shipping cost</Label>
                <Input
                  id="ship"
                  value={settings.shippingCost}
                  onChange={(e) => setSettings({ shippingCost: e.target.value })}
                  placeholder="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="handle">Handling days</Label>
                <Input
                  id="handle"
                  value={settings.handlingDays}
                  onChange={(e) => setSettings({ handlingDays: e.target.value })}
                  placeholder="1"
                />
              </div>
            </div>
          </section>

          <Separator />

          <section className="space-y-3">
            <h3 className="text-sm font-medium">Rebrickable</h3>
            <p className="text-sm text-muted">
              Optional. A free key from rebrickable.com/api lets lookups hit their live API for brand-new sets. The daily catalog already covers the rest.
            </p>
            <div className="space-y-2">
              <Label htmlFor="rb">API key</Label>
              <Input
                id="rb"
                type="password"
                autoComplete="off"
                value={settings.rebrickableApiKey}
                onChange={(e) => setSettings({ rebrickableApiKey: e.target.value })}
                placeholder="Paste key"
              />
            </div>
          </section>

          <Separator />

          <section className="space-y-3">
            <h3 className="text-sm font-medium">eBay</h3>
            <p className="text-sm text-muted">
              App ID + Cert ID power used-price comps. A user token from the eBay developer portal lets GBblox publish a listing for you.
            </p>
            <div className="space-y-2">
              <Label htmlFor="cid">App ID (Client ID)</Label>
              <Input
                id="cid"
                type="password"
                autoComplete="off"
                value={settings.ebayClientId}
                onChange={(e) => setSettings({ ebayClientId: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="csec">Cert ID (Client Secret)</Label>
              <Input
                id="csec"
                type="password"
                autoComplete="off"
                value={settings.ebayClientSecret}
                onChange={(e) => setSettings({ ebayClientSecret: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tok">User token</Label>
              <Input
                id="tok"
                type="password"
                autoComplete="off"
                value={settings.ebayUserToken}
                onChange={(e) => setSettings({ ebayUserToken: e.target.value })}
                placeholder="OAuth user access token"
              />
            </div>
            <Button
              variant="secondary"
              className="w-full"
              disabled={!settings.ebayUserToken.trim() || test.isPending}
              onClick={() => test.mutate()}
            >
              {test.isPending ? <Loader2 className="animate-spin" /> : <Check />}
              Test token
            </Button>
            <ol className="list-decimal space-y-1.5 pl-4 text-xs leading-relaxed text-muted">
              <li>Create an app at developer.ebay.com</li>
              <li>Copy Production App ID and Cert ID for used-price search</li>
              <li>Generate a User access token with sell inventory / trading scopes</li>
              <li>Paste the token here, then List on eBay from any set</li>
            </ol>
          </section>

          <Separator />

          <section className="space-y-3">
            <h3 className="text-sm font-medium">BrickLink store</h3>
            <p className="text-sm text-muted">
              Store API keys power the BrickLink price guide (new and used), match lots when Remarks equals SKU, and list a set with that SKU in Remarks.
            </p>
            <div className="space-y-2">
              <Label htmlFor="bl-ck">Consumer key</Label>
              <Input
                id="bl-ck"
                type="password"
                autoComplete="off"
                value={settings.blConsumerKey}
                onChange={(e) => setSettings({ blConsumerKey: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bl-cs">Consumer secret</Label>
              <Input
                id="bl-cs"
                type="password"
                autoComplete="off"
                value={settings.blConsumerSecret}
                onChange={(e) => setSettings({ blConsumerSecret: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bl-tok">Token</Label>
              <Input
                id="bl-tok"
                type="password"
                autoComplete="off"
                value={settings.blToken}
                onChange={(e) => setSettings({ blToken: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bl-ts">Token secret</Label>
              <Input
                id="bl-ts"
                type="password"
                autoComplete="off"
                value={settings.blTokenSecret}
                onChange={(e) => setSettings({ blTokenSecret: e.target.value })}
              />
            </div>
            <Button
              variant="secondary"
              className="w-full"
              disabled={!bricklinkCanSync(settings) || testBl.isPending}
              onClick={() => testBl.mutate()}
            >
              {testBl.isPending ? <Loader2 className="animate-spin" /> : <Check />}
              Test BrickLink
            </Button>
            <ol className="list-decimal space-y-1.5 pl-4 text-xs leading-relaxed text-muted">
              <li>Open bricklink.com/v3/api.page and register an app</li>
              <li>Copy consumer key, consumer secret, token, and token secret</li>
              <li>When you list from GBblox, the unique SKU is written to the BrickLink Remarks field</li>
              <li>Match SKU reads store inventories and marks Listed only when Remarks equals the app SKU</li>
            </ol>
          </section>

          <Separator />

          <section className="space-y-3">
            <h3 className="text-sm font-medium">Royal Mail Click & Drop</h3>
            <p className="text-sm text-muted">
              Authorisation key from Click & Drop integrations. Used on an order to pay for postage and print a label.
            </p>
            <div className="space-y-2">
              <Label htmlFor="rm-key">Authorisation key</Label>
              <Input
                id="rm-key"
                type="password"
                autoComplete="off"
                value={settings.royalMailApiKey}
                onChange={(e) => setSettings({ royalMailApiKey: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rm-sender">Trading name on labels</Label>
              <Input
                id="rm-sender"
                value={settings.royalMailSenderName}
                onChange={(e) => setSettings({ royalMailSenderName: e.target.value })}
                placeholder="Optional sender name"
              />
            </div>
            <Button
              variant="secondary"
              className="w-full"
              disabled={!royalMailCanPost(settings) || testRm.isPending}
              onClick={() => testRm.mutate()}
            >
              {testRm.isPending ? <Loader2 className="animate-spin" /> : <Check />}
              Test Click & Drop
            </Button>
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}
